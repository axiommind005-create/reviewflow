-- REVIEWFLOW initial multi-tenant schema
-- Apply in Supabase SQL Editor. All tenant-owned records are scoped by organization_id.
create extension if not exists pgcrypto;

create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 120),
  slug text unique,
  owner_id uuid not null references auth.users(id) on delete restrict,
  plan text not null default 'free' check (plan in ('free','pro','business')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.memberships (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','manager','member')),
  created_at timestamptz not null default now(),
  unique (organization_id, user_id)
);

create table if not exists public.locations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  address text,
  timezone text not null default 'UTC',
  created_at timestamptz not null default now()
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  location_id uuid references public.locations(id) on delete set null,
  full_name text not null,
  email text,
  phone text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  location_id uuid references public.locations(id) on delete set null,
  customer_id uuid references public.customers(id) on delete set null,
  source text not null default 'manual',
  external_id text,
  author_name text,
  rating smallint not null check (rating between 1 and 5),
  review_text text,
  status text not null default 'new' check (status in ('new','needs_reply','replied','archived')),
  reply_text text,
  replied_at timestamptz,
  review_date timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique (organization_id, source, external_id)
);

create table if not exists public.review_requests (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  location_id uuid references public.locations(id) on delete set null,
  customer_id uuid references public.customers(id) on delete set null,
  channel text not null default 'link' check (channel in ('link','email','sms','whatsapp','qr')),
  destination text,
  status text not null default 'draft' check (status in ('draft','queued','sent','opened','completed','failed')),
  scheduled_at timestamptz,
  sent_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.workflows (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  trigger_type text not null default 'manual',
  config jsonb not null default '{}'::jsonb,
  is_active boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists memberships_user_id_idx on public.memberships(user_id);
create index if not exists locations_org_idx on public.locations(organization_id);
create index if not exists customers_org_idx on public.customers(organization_id);
create index if not exists reviews_org_date_idx on public.reviews(organization_id, review_date desc);
create index if not exists review_requests_org_created_idx on public.review_requests(organization_id, created_at desc);
create index if not exists workflows_org_idx on public.workflows(organization_id);

-- SECURITY DEFINER helpers avoid recursive membership RLS checks.
create or replace function public.is_org_member(org_id uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.memberships m where m.organization_id = org_id and m.user_id = auth.uid()); $$;

create or replace function public.is_org_admin(org_id uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.memberships m where m.organization_id = org_id and m.user_id = auth.uid() and m.role in ('owner','admin')); $$;

create or replace function public.create_organization(org_name text)
returns uuid language plpgsql security definer set search_path = public
as $$
declare new_org_id uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if char_length(trim(org_name)) < 2 or char_length(trim(org_name)) > 120 then raise exception 'Organization name must be 2-120 characters'; end if;
  insert into public.organizations(name, owner_id) values (trim(org_name), auth.uid()) returning id into new_org_id;
  insert into public.memberships(organization_id, user_id, role) values (new_org_id, auth.uid(), 'owner');
  return new_org_id;
end; $$;
revoke all on function public.create_organization(text) from public;
grant execute on function public.create_organization(text) to authenticated;

alter table public.organizations enable row level security;
alter table public.memberships enable row level security;
alter table public.locations enable row level security;
alter table public.customers enable row level security;
alter table public.reviews enable row level security;
alter table public.review_requests enable row level security;
alter table public.workflows enable row level security;

create policy "members can read organizations" on public.organizations for select to authenticated using (public.is_org_member(id));
create policy "owners can update organizations" on public.organizations for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "users can read own memberships" on public.memberships for select to authenticated using (user_id = auth.uid() or public.is_org_admin(organization_id));
create policy "admins can add memberships" on public.memberships for insert to authenticated with check (public.is_org_admin(organization_id));
create policy "admins can update memberships" on public.memberships for update to authenticated using (public.is_org_admin(organization_id)) with check (public.is_org_admin(organization_id));
create policy "admins can remove memberships" on public.memberships for delete to authenticated using (public.is_org_admin(organization_id));

create policy "members manage locations" on public.locations for all to authenticated using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy "members manage customers" on public.customers for all to authenticated using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy "members manage reviews" on public.reviews for all to authenticated using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy "members manage review requests" on public.review_requests for all to authenticated using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy "members manage workflows" on public.workflows for all to authenticated using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));

-- No service-role key belongs in browser code. Add integrations only through trusted server-side functions.
