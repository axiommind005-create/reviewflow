# REVIEWFLOW — next setup package

This package contains the latest saved REVIEWFLOW interface (`index.html`) and the first Supabase database migration.

## Current state
- `index.html` is still a standalone front-end prototype. It uses browser `localStorage` and does not connect to Supabase yet.
- `supabase/migrations/20261126110000_initial_schema.sql` creates the first multi-tenant data model and enables Row Level Security (RLS).
- `.env.example` documents the public Supabase client settings. The current HTML does not consume these values yet.

## Next setup
1. Create a private GitHub repository named `reviewflow`.
2. Upload `index.html`, `.env.example`, `README.md`, and the `supabase` folder, preserving the folder structure.
3. In Supabase, open **SQL Editor → New query**, paste the migration SQL, and run it.
4. Confirm the migration completed successfully before connecting the UI.
5. Import the GitHub repository into Vercel and deploy the static prototype. Configure a custom domain later.

## Security notes
- Do not commit passwords, API secrets, or a Supabase service-role key.
- The anon/publishable key is intended for browser use only when every exposed table has correct RLS policies.
- Review and test all policies before using real customer data. The current prototype is not production-ready and does not yet use this database.
- Email/SMS delivery, review-platform integrations, billing, and production monitoring are not implemented by this package.
